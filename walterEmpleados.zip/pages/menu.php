<ul>
    <li><a href="../index.php">Inicio</a></li>
    <li><a href="empleado.php">Empleados</a></li>
    <li><a href="asignarCargos.php">Asignar Cargos</a></li>
    <li><a href="asignarJefe.php">Asignar Jefes</a></li>
    <li><a href="asignarColaborador.php">Asignar Colaboraciones</a></li>
</ul>