<?php

$cnx = mysqli_connect("localhost", "root", "", "walterempleados");


?>